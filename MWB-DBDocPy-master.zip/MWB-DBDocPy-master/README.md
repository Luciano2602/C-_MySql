MWB-DBDocPy
===========

MySQL Workbench DBDoc Python Plugin

An utility for MySQL Workbench to generate data dictionaries (DBDoc)

Install it through Scripting/Install Plugin/Module menu
select DBDocPy_grt.py file, restart MWB for the change to take effect.

It can be accessed through Tools/Catalog menu, there are 2 options:
A text version, displayed at MWB console
An HTML version, exported to a file

I've never programmed in Python before, take it in mind and please be kind.
Any suggestions are welcome. Please leave your contribution.

**This plugin doesn't work with version 6.x.
You may take a look at http://tmsanchezdev.blogspot.com.br/2015/03/html-report-from-mysqlworkbench-6x.html for a plugin compatible with version 6.x.**
